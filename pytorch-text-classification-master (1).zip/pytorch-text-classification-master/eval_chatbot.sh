
perl multi_bleu.perl data/Q1-recom-elno_cleaned_data_current/test_target.csv < data/Q1-recom-elno_cleaned_data_current/test_predict.csv
